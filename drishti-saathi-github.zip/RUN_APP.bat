@echo off
title Drishti Saathi Local Host
echo Launching Drishti Saathi Local Server...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0server.ps1"
pause

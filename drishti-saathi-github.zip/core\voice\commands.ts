/**
 * Drishti Saathi - Bilingual Command Registry & Matcher
 * Supports English, Hindi (Devanagari), and Hinglish (Latin script)
 */

import { VoiceIntent, MatchedCommand, SupportedLanguage } from './types';

interface PatternRule {
  intent: VoiceIntent;
  patterns: RegExp[];
  languageHint?: SupportedLanguage;
}

const COMMAND_RULES: PatternRule[] = [
  // 1. Scene Description
  {
    intent: VoiceIntent.DESCRIBE_SCENE,
    patterns: [
      /\b(what(?:'s| is) in front(?: of me)?|describe (?:the )?scene|what do you see|look around|what is ahead)\b/i,
      /(सामने क्या है|क्या दिख रहा है|आसपास क्या है|आगे क्या है|दृश्य बताओ|क्या है सामने|सामने देखो)/u,
      /\b(samne kya hai|kya dikh raha hai|aage kya hai|aaspas kya hai|kya hai samne|drishya batao)\b/i,
    ],
  },

  // 2. Start / Resume Navigation
  {
    intent: VoiceIntent.START_NAVIGATION,
    patterns: [
      /\b(start(?: navigation)?|begin(?: walking)?|start guidance|turn on navigation|activate)\b/i,
      /(नेविगेशन शुरू करो|शुरू करो|चालू करो|चलना शुरू करो|आरंभ करो)/u,
      /\b(shuru karo|navigation shuru karo|chalu karo|start karo)\b/i,
    ],
  },

  // 3. Pause Navigation
  {
    intent: VoiceIntent.PAUSE_NAVIGATION,
    patterns: [
      /\b(pause(?: navigation)?|hold on|wait a moment|standby)\b/i,
      /(पॉज़ करो|रुको|थोड़ा रुको|ठहरो|विराम)/u,
      /\b(ruko|pause karo|thoda ruko|ruk jao)\b/i,
    ],
  },

  // 4. Resume Navigation
  {
    intent: VoiceIntent.RESUME_NAVIGATION,
    patterns: [
      /\b(resume(?: navigation)?|continue(?: walking)?|keep going|unpause)\b/i,
      /(फिर से शुरू करो|आगे बढ़ो|जारी रखो)/u,
      /\b(phir se shuru karo|aage badho|continue karo)\b/i,
    ],
  },

  // 5. Stop Navigation
  {
    intent: VoiceIntent.STOP_NAVIGATION,
    patterns: [
      /\b(stop(?: navigation)?|shut down|turn off|disable guidance|quit|exit)\b/i,
      /(नेविगेशन बंद करो|बंद करो|रोको|समाप्त करो)/u,
      /\b(band karo|navigation band karo|roko|stop karo)\b/i,
    ],
  },

  // 6. Check Path / Obstacle Status
  {
    intent: VoiceIntent.CHECK_PATH_STATUS,
    patterns: [
      /\b(is (?:the )?path clear|any obstacles|can i walk|is it safe|road clear|path status)\b/i,
      /(क्या रास्ता साफ है|रास्ता साफ है|कोई रुकावट है|क्या मैं चल सकता हूँ|रास्ता कैसा है)/u,
      /\b(kya rasta saaf hai|rasta saaf hai|koi rukawat hai|kya mai chal sakta hu)\b/i,
    ],
  },

  // 7. Repeat Last Alert
  {
    intent: VoiceIntent.REPEAT_LAST_ALERT,
    patterns: [
      /\b(repeat(?: that)?|say (?:that )?again|what did you say|pardon|repeat last alert)\b/i,
      /(फिर से बोलो|दोहराओ|क्या कहा|दोबारा बोलो)/u,
      /\b(phir se bolo|dobara bolo|kya kaha|dohrao)\b/i,
    ],
  },

  // 8. Language: Switch to Hindi
  {
    intent: VoiceIntent.SET_LANGUAGE_HINDI,
    languageHint: 'hi',
    patterns: [
      /\b(speak hindi|switch to hindi|hindi language|hindi mode|talk in hindi)\b/i,
      /(हिंदी में बोलो|हिंदी भाषा|हिंदी करो|हिंदी मोड)/u,
      /\b(hindi me bolo|hindi bhasha|hindi mode|hindi karo)\b/i,
    ],
  },

  // 9. Language: Switch to English
  {
    intent: VoiceIntent.SET_LANGUAGE_ENGLISH,
    languageHint: 'en',
    patterns: [
      /\b(speak english|switch to english|english language|english mode|talk in english)\b/i,
      /(अंग्रेजी में बोलो|इंग्लिश में बोलो|अंग्रेजी भाषा|इंग्लिश मोड)/u,
      /\b(angrezi me bolo|english me bolo|english language|english mode)\b/i,
    ],
  },

  // 10. Speech Speed Adjustments
  {
    intent: VoiceIntent.INCREASE_SPEED,
    patterns: [
      /\b(speak faster|talk faster|increase speed|faster speech)\b/i,
      /(तेज़ बोलो|गति बढ़ाओ|जल्दी बोलो)/u,
      /\b(tez bolo|jaldi bolo|speed badhao)\b/i,
    ],
  },
  {
    intent: VoiceIntent.DECREASE_SPEED,
    patterns: [
      /\b(speak slower|talk slower|decrease speed|slow down voice)\b/i,
      /(धीमे बोलो|आराम से बोलो|गति कम करो)/u,
      /\b(dheeme bolo|aaram se bolo|speed kam karo)\b/i,
    ],
  },

  // 11. Mute / Unmute
  {
    intent: VoiceIntent.MUTE,
    patterns: [
      /\b(mute(?: alerts)?|be quiet|silence|shh)\b/i,
      /(म्यूट करो|शांत रहो|चुप रहो|आवाज बंद)/u,
      /\b(mute karo|shant raho|chup raho|aawaz band)\b/i,
    ],
  },
  {
    intent: VoiceIntent.UNMUTE,
    patterns: [
      /\b(unmute(?: alerts)?|speak up|turn sound on)\b/i,
      /(अनम्यूट करो|आवाज चालू|बोलना शुरू करो)/u,
      /\b(unmute karo|aawaz chalu)\b/i,
    ],
  },

  // 12. Help / Guidance
  {
    intent: VoiceIntent.HELP,
    patterns: [
      /\b(help(?: me)?|what can i say|list commands|how does this work|instructions)\b/i,
      /(मदद करो|मदद|कमांड बताओ|मैं क्या बोल सकता हूँ|सहायता)/u,
      /\b(madad karo|madad|kya bol sakta hu|commands batao|help)\b/i,
    ],
  },

  // 13. Battery / Health Status
  {
    intent: VoiceIntent.BATTERY_STATUS,
    patterns: [
      /\b(battery status|battery level|check battery|how much battery)\b/i,
      /(बैटरी कितनी है|बैटरी बताओ|चार्जिंग कितनी है)/u,
      /\b(battery kitni hai|battery batao|charging kitni hai)\b/i,
    ],
  },
];

/**
 * Match a raw voice transcription to a registered VoiceIntent.
 * Supports normalization, punctuation stripping, and Devanagari detection.
 */
export function matchVoiceCommand(
  rawTranscript: string,
  fallbackLanguage: SupportedLanguage = 'en'
): MatchedCommand {
  const cleaned = rawTranscript.trim().toLowerCase();

  // Detect script (Devanagari presence)
  const hasDevanagari = /[\u0900-\u097F]/.test(cleaned);
  const detectedLanguage: SupportedLanguage = hasDevanagari ? 'hi' : fallbackLanguage;

  for (const rule of COMMAND_RULES) {
    for (const pattern of rule.patterns) {
      if (pattern.test(cleaned)) {
        return {
          intent: rule.intent,
          rawText: rawTranscript,
          confidence: 0.95,
          detectedLanguage: rule.languageHint || detectedLanguage,
          matchedPattern: pattern.source,
        };
      }
    }
  }

  return {
    intent: VoiceIntent.UNKNOWN,
    rawText: rawTranscript,
    confidence: 0.0,
    detectedLanguage,
  };
}

/**
 * Localized response messages for system actions
 */
export const INTENT_RESPONSES: Record<VoiceIntent, Record<SupportedLanguage, string>> = {
  [VoiceIntent.DESCRIBE_SCENE]: {
    en: 'Analyzing scene in front of you.',
    hi: 'सामने के दृश्य का विश्लेषण किया जा रहा है।',
  },
  [VoiceIntent.START_NAVIGATION]: {
    en: 'Navigation started. Detecting obstacles.',
    hi: 'नेविगेशन शुरू हो गया है। रुकावटों की निगरानी जारी है।',
  },
  [VoiceIntent.PAUSE_NAVIGATION]: {
    en: 'Navigation paused.',
    hi: 'नेविगेशन रोक दिया गया है।',
  },
  [VoiceIntent.RESUME_NAVIGATION]: {
    en: 'Navigation resumed.',
    hi: 'नेविगेशन दोबारा शुरू हो गया है।',
  },
  [VoiceIntent.STOP_NAVIGATION]: {
    en: 'Navigation stopped.',
    hi: 'नेविगेशन बंद कर दिया गया है।',
  },
  [VoiceIntent.CHECK_PATH_STATUS]: {
    en: 'Checking your walking path.',
    hi: 'आपके रास्ते की जांच की जा रही है।',
  },
  [VoiceIntent.REPEAT_LAST_ALERT]: {
    en: 'Repeating previous alert.',
    hi: 'पिछली चेतावनी दोहराई जा रही है।',
  },
  [VoiceIntent.SET_LANGUAGE_HINDI]: {
    en: 'Switched to Hindi. अब से चेतावनी हिंदी में होगी।',
    hi: 'अब से चेतावनी हिंदी में होगी।',
  },
  [VoiceIntent.SET_LANGUAGE_ENGLISH]: {
    en: 'Switched to English. Alerts will now be in English.',
    hi: 'भाषा बदलकर अंग्रेजी कर दी गई है।',
  },
  [VoiceIntent.INCREASE_SPEED]: {
    en: 'Speech speed increased.',
    hi: 'बोलने की गति बढ़ा दी गई है।',
  },
  [VoiceIntent.DECREASE_SPEED]: {
    en: 'Speech speed decreased.',
    hi: 'बोलने की गति कम कर दी गई है।',
  },
  [VoiceIntent.MUTE]: {
    en: 'Voice alerts muted. Tap screen twice to unmute.',
    hi: 'आवाज बंद कर दी गई है। दोबारा शुरू करने के लिए स्क्रीन पर दो बार टैप करें।',
  },
  [VoiceIntent.UNMUTE]: {
    en: 'Voice alerts unmuted.',
    hi: 'आवाज चालू कर दी गई है।',
  },
  [VoiceIntent.HELP]: {
    en: 'You can say: What is in front of me, Is path clear, Start navigation, Stop, or Switch to Hindi.',
    hi: 'आप बोल सकते हैं: सामने क्या है, रास्ता साफ है, नेविगेशन शुरू करो, रोको, या अंग्रेजी में बोलो।',
  },
  [VoiceIntent.BATTERY_STATUS]: {
    en: 'Checking device battery level.',
    hi: 'बैटरी की स्थिति जांची जा रही है।',
  },
  [VoiceIntent.UNKNOWN]: {
    en: 'Command not recognized. Say "Help" for options.',
    hi: 'कमांड समझ नहीं आई। सहायता के लिए "मदद" बोलें।',
  },
};

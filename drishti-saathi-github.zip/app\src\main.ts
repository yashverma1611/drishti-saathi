/**
 * Drishti Saathi - Frontend Application Entrypoint
 * Integrates camera stream, voice control system, and risk evaluation into the Neural Model HUD.
 */

import { VoiceController } from '../../core/voice/voice_controller';
import { VoiceIntent, MatchedCommand, SupportedLanguage, SpeechPriority } from '../../core/voice/types';
import { SpatialRiskEngine, DetectedObject } from '../../core/risk/risk_engine';

class DrishtiSaathiApp {
  private voice: VoiceController;
  private riskEngine: SpatialRiskEngine;
  private currentLanguage: SupportedLanguage = 'hi';
  private videoElement: HTMLVideoElement | null = null;
  private isNavigationActive: boolean = true;

  // DOM Elements
  private statusText!: HTMLElement;
  private listeningText!: HTMLElement;
  private centerSubtitle!: HTMLElement;
  private btnVoiceToggle!: HTMLElement;
  private btnIcon!: HTMLElement;
  private btnText!: HTMLElement;
  private srAssertive!: HTMLElement;
  private srPolite!: HTMLElement;
  private systemLogsContainer!: HTMLElement;
  private clockDisplay!: HTMLElement;

  // Telemetry elements
  private teleFps!: HTMLElement;
  private teleObjects!: HTMLElement;
  private teleClearance!: HTMLElement;
  private teleGradient!: HTMLElement;
  private teleRisk!: HTMLElement;

  constructor() {
    this.riskEngine = new SpatialRiskEngine();

    this.voice = new VoiceController({
      defaultLanguage: this.currentLanguage,
      continuousMode: true,
      onCommandMatched: (cmd) => this.onCommandMatched(cmd),
      onStateChange: (state) => this.onVoiceStateChange(state),
      onTranscript: (txt) => this.onTranscriptReceived(txt),
    });

    this.initDOM();
    this.initCamera();
    this.startClock();
    this.registerServiceWorker();
  }

  private initDOM(): void {
    this.statusText = document.getElementById('status-text')!;
    this.listeningText = document.getElementById('listening-text')!;
    this.centerSubtitle = document.getElementById('center-subtitle')!;
    this.btnVoiceToggle = document.getElementById('btn-voice-toggle')!;
    this.btnIcon = document.getElementById('btn-icon')!;
    this.btnText = document.getElementById('btn-text')!;
    this.srAssertive = document.getElementById('sr-assertive-announcer')!;
    this.srPolite = document.getElementById('sr-polite-announcer')!;
    this.systemLogsContainer = document.getElementById('system-logs-container')!;
    this.clockDisplay = document.getElementById('clock-display')!;
    this.videoElement = document.getElementById('camera-preview') as HTMLVideoElement;

    // Telemetry fields
    this.teleFps = document.getElementById('tele-fps')!;
    this.teleObjects = document.getElementById('tele-objects')!;
    this.teleClearance = document.getElementById('tele-clearance')!;
    this.teleGradient = document.getElementById('tele-gradient')!;
    this.teleRisk = document.getElementById('tele-risk')!;

    // Tap to speak (Spacebar or big button)
    this.btnVoiceToggle.addEventListener('click', () => {
      this.voice.triggerPushToTalk();
    });

    // Language Toggle
    document.getElementById('btn-lang-toggle')?.addEventListener('click', () => {
      this.toggleLanguage();
    });

    // Quick Voice Action: "What's in front of me?"
    document.getElementById('btn-quick-scene')?.addEventListener('click', () => {
      this.voice.handleTranscript(this.currentLanguage === 'hi' ? 'सामने क्या है' : 'What is in front of me');
    });

    // Test Stairs Hazard Simulation
    document.getElementById('btn-test-stairs')?.addEventListener('click', () => {
      this.triggerSimulatedHazard();
    });

    // Test Clear Path Simulation
    document.getElementById('btn-quick-path')?.addEventListener('click', () => {
      this.simulatePathCheck();
    });

    // Global keyboard accessibility: Spacebar triggers voice
    window.addEventListener('keydown', (e) => {
      if (e.code === 'Space' && (e.target === document.body || e.target === this.btnVoiceToggle)) {
        e.preventDefault();
        this.voice.triggerPushToTalk();
      }
    });
  }

  private async initCamera(): Promise<void> {
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'environment', width: { ideal: 640 }, height: { ideal: 480 } },
          audio: false,
        });
        if (this.videoElement) {
          this.videoElement.srcObject = stream;
        }
        this.addLog('AI: Camera feed synced (640x480)', '#00f0ff');
      }
    } catch (err) {
      this.addLog('AI: Camera offline, using simulated visual frame buffer', '#ffd000');
    }
  }

  private onCommandMatched(cmd: MatchedCommand): void {
    this.centerSubtitle.innerText = `"${cmd.rawText}"`;
    this.announcePolite(`Command recognized: ${cmd.rawText}`);
    this.addLog(`VOICE: Command matched [${cmd.intent}]`, '#ffd000');

    switch (cmd.intent) {
      case VoiceIntent.START_NAVIGATION:
        this.isNavigationActive = true;
        this.statusText.innerText = 'Navigation active';
        break;

      case VoiceIntent.PAUSE_NAVIGATION:
      case VoiceIntent.STOP_NAVIGATION:
        this.isNavigationActive = false;
        this.statusText.innerText = 'Navigation standby';
        break;

      case VoiceIntent.DESCRIBE_SCENE:
        this.simulateSceneDescription();
        break;

      case VoiceIntent.CHECK_PATH_STATUS:
        this.simulatePathCheck();
        break;

      case VoiceIntent.SET_LANGUAGE_HINDI:
        this.setLanguage('hi');
        break;

      case VoiceIntent.SET_LANGUAGE_ENGLISH:
        this.setLanguage('en');
        break;
    }
  }

  private onVoiceStateChange(state: string): void {
    if (state === 'LISTENING') {
      this.btnVoiceToggle.classList.replace('bg-[#ffd000]', 'bg-emerald-500');
      this.btnText.innerText = 'LISTENING... (बोलिए)';
      this.btnIcon.innerText = '🔴';
      this.listeningText.innerText = 'MIC: LISTENING';
      this.listeningText.parentElement?.classList.replace('text-[#ffd000]', 'text-emerald-400');
      this.addLog('VOICE: Microphone active', '#22c55e');
    } else {
      this.btnVoiceToggle.classList.replace('bg-emerald-500', 'bg-[#ffd000]');
      this.btnText.innerText = 'ACTIVATE VOICE MODE';
      this.btnIcon.innerText = '🎙️';
      this.listeningText.innerText = 'VOICE: READY';
      this.listeningText.parentElement?.classList.replace('text-emerald-400', 'text-[#ffd000]');
    }
  }

  private onTranscriptReceived(transcript: string): void {
    this.centerSubtitle.innerText = `"${transcript}"`;
  }

  private toggleLanguage(): void {
    const nextLang = this.currentLanguage === 'hi' ? 'en' : 'hi';
    this.setLanguage(nextLang);
  }

  private setLanguage(lang: SupportedLanguage): void {
    this.currentLanguage = lang;
    this.voice.setLanguage(lang);
    const langBtn = document.getElementById('btn-lang-toggle');
    if (langBtn) {
      langBtn.innerText = lang === 'hi' ? '🌐 भाषा: हिन्दी' : '🌐 Lang: ENGLISH';
    }
    const msg = lang === 'hi' ? 'भाषा बदलकर हिंदी कर दी गई है।' : 'Switched to English language mode.';
    this.announcePolite(msg);
    this.addLog(`SYSTEM: Language switched to ${lang.toUpperCase()}`, '#00f0ff');
  }

  private announceAssertive(text: string): void {
    if (this.srAssertive) this.srAssertive.innerText = text;
  }

  private announcePolite(text: string): void {
    if (this.srPolite) this.srPolite.innerText = text;
  }

  /**
   * Simulated Scene Description (when user asks "What is in front of me?")
   */
  private simulateSceneDescription(): void {
    const descEn = 'Directly ahead are descending stairs 1.1 meters away. A person is walking on your left.';
    const descHi = 'सामने 1.1 मीटर की दूरी पर नीचे जाती सीढ़ियाँ हैं। आपकी बाईं तरफ एक व्यक्ति चल रहा है।';
    const text = this.currentLanguage === 'hi' ? descHi : descEn;
    this.centerSubtitle.innerText = `"${text}"`;
    this.voice.handleStandardAlert(text, SpeechPriority.HIGH);
    this.addLog(`AI VLM: ${text}`, '#00f0ff');
  }

  /**
   * Simulated Path Check
   */
  private simulatePathCheck(): void {
    const clearEn = 'The walking path directly ahead is now completely clear for 4 meters.';
    const clearHi = 'सामने का रास्ता अगले 4 मीटर तक पूरी तरह साफ है।';
    const text = this.currentLanguage === 'hi' ? clearHi : clearEn;

    // Update telemetry
    this.teleClearance.innerText = '4.0 m (CLEAR)';
    this.teleClearance.className = 'text-[#22c55e] font-bold';
    this.teleRisk.innerText = '15 / 100';
    this.teleRisk.className = 'text-[#22c55e] font-bold';

    // Hide stairs bbox
    const stairsBox = document.getElementById('bbox-stairs');
    if (stairsBox) stairsBox.style.display = 'none';

    this.centerSubtitle.innerText = `"${text}"`;
    this.voice.handleStandardAlert(text, SpeechPriority.NORMAL);
    this.addLog(`AI: Path Clear confirmed`, '#22c55e');
  }

  /**
   * Trigger critical obstacle alert (e.g. from vision model loop)
   */
  public triggerSimulatedHazard(): void {
    const mockHazard: DetectedObject = {
      label: 'stairs',
      confidence: 0.94,
      bbox: { xMin: 0.35, yMin: 0.45, xMax: 0.65, yMax: 0.9 },
      depthZone: 'VERY_CLOSE',
    };

    const assessment = this.riskEngine.evaluateRisk(mockHazard);
    const text = assessment.alertText[this.currentLanguage];

    // Show stairs bbox
    const stairsBox = document.getElementById('bbox-stairs');
    if (stairsBox) stairsBox.style.display = 'flex';

    // Update telemetry
    this.teleClearance.innerText = '1.1 m (BLOCKED)';
    this.teleClearance.className = 'text-[#ef4444] font-bold';
    this.teleRisk.innerText = '92 / 100';
    this.teleRisk.className = 'text-[#ef4444] font-bold';

    this.centerSubtitle.innerText = `"${text}"`;
    this.announceAssertive(text);
    this.addLog(`CRITICAL: ${text}`, '#ef4444');

    // Preempt all speech and speak danger warning
    this.voice.handleCriticalHazard(text, this.currentLanguage);
  }

  private addLog(message: string, color: string = '#00f0ff'): void {
    if (!this.systemLogsContainer) return;
    const now = new Date();
    const time = `[${now.toTimeString().split(' ')[0]}]`;
    const item = document.createElement('div');
    item.style.color = color;
    item.innerText = `${time} ${message}`;
    this.systemLogsContainer.prepend(item);
  }

  private startClock(): void {
    setInterval(() => {
      if (this.clockDisplay) {
        const d = new Date();
        this.clockDisplay.innerText = d.toTimeString().split(' ')[0];
      }
      // Subtle jitter to simulate live inference loop
      if (this.teleFps) {
        this.teleFps.innerText = (8.2 + Math.random() * 0.8).toFixed(1);
      }
    }, 1000);
  }

  private registerServiceWorker(): void {
    if ('serviceWorker' in navigator) {
      window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js').catch((err) => {
          console.warn('SW registration skipped:', err);
        });
      });
    }
  }
}

// Global hook for navigation mode switcher
(window as any).switchMode = function(mode: string) {
  if (mode === 'reader') {
    window.location.href = '/vocalis_suite.html';
  } else if (mode === 'settings') {
    window.location.href = '/vocalis_suite.html';
  } else {
    alert('Vision Model HUD is the active primary mode.');
  }
};

// Bootstrap on DOM content loaded
document.addEventListener('DOMContentLoaded', () => {
  (window as any).drishtiApp = new DrishtiSaathiApp();
});

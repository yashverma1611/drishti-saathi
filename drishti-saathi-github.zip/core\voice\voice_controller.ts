/**
 * Drishti Saathi - Master Voice Controller
 * Coordinates hands-free / gesture-activated speech recognition, intent matching,
 * audio cue earcons, TTS priority feedback, and mic ducking.
 */

import {
  VoiceIntent,
  MatchedCommand,
  SupportedLanguage,
  VoiceState,
  AudioCueType,
  SpeechPriority,
} from './types';
import { matchVoiceCommand, INTENT_RESPONSES } from './commands';
import { AudioCueManager } from './audio_cues';
import { TTSEngine } from './tts_engine';

export interface VoiceControllerConfig {
  defaultLanguage: SupportedLanguage;
  continuousMode: boolean; // Continuous background listening vs Push-to-talk
  onCommandMatched?: (command: MatchedCommand) => void;
  onStateChange?: (state: VoiceState) => void;
  onTranscript?: (interim: string, isFinal: boolean) => void;
}

export class VoiceController {
  private state: VoiceState = 'IDLE';
  private config: VoiceControllerConfig;
  private recognition: any = null;
  private audioCues: AudioCueManager;
  private tts: TTSEngine;

  private isRecognizing: boolean = false;
  private isDucked: boolean = false; // Muted while phone's own speaker is speaking
  private restartTimeout: any = null;
  private lastAlertText: string = 'No recent alerts.';

  constructor(config: Partial<VoiceControllerConfig> = {}) {
    this.config = {
      defaultLanguage: config.defaultLanguage || 'en',
      continuousMode: config.continuousMode ?? true,
      onCommandMatched: config.onCommandMatched,
      onStateChange: config.onStateChange,
      onTranscript: config.onTranscript,
    };

    this.audioCues = new AudioCueManager();
    this.tts = new TTSEngine();
    this.tts.setLanguage(this.config.defaultLanguage);

    this.setupMicDucking();
    this.initSpeechRecognition();
  }

  /**
   * Automatic echo cancellation / mic ducking:
   * When TTS speaks, mute or ignore microphone so phone doesn't recognize its own voice.
   */
  private setupMicDucking(): void {
    this.tts.onSpeechStart = () => {
      this.isDucked = true;
      if (this.recognition && this.isRecognizing) {
        try {
          this.recognition.abort();
        } catch (_) {}
      }
    };

    this.tts.onSpeechEnd = () => {
      this.isDucked = false;
      if (this.config.continuousMode && this.state !== 'MUTED' && this.state !== 'DISABLED') {
        this.scheduleRestart(250);
      }
    };
  }

  /**
   * Initialize browser SpeechRecognition (Web Speech API)
   */
  private initSpeechRecognition(): boolean {
    const SpeechRec =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRec) {
      console.warn('VoiceController: SpeechRecognition is not supported on this platform/browser');
      this.setState('DISABLED');
      return false;
    }

    try {
      this.recognition = new SpeechRec();
      this.recognition.continuous = this.config.continuousMode;
      this.recognition.interimResults = false;
      this.recognition.maxAlternatives = 1;
      this.updateRecognitionLanguage();

      this.recognition.onstart = () => {
        this.isRecognizing = true;
        this.setState('LISTENING');
      };

      this.recognition.onresult = (event: any) => {
        if (this.isDucked) return; // Discard speaker feedback

        const lastResult = event.results[event.results.length - 1];
        if (lastResult && lastResult.isFinal) {
          const transcript = lastResult[0].transcript;
          this.handleTranscript(transcript);
        }
      };

      this.recognition.onerror = (event: any) => {
        if (event.error === 'no-speech' || event.error === 'aborted') {
          // Normal timeouts in speech detection
          return;
        }
        console.warn('VoiceController recognition error:', event.error);
        if (event.error === 'not-allowed') {
          this.setState('DISABLED');
          this.audioCues.playCue(AudioCueType.COMMAND_ERROR);
        }
      };

      this.recognition.onend = () => {
        this.isRecognizing = false;
        if (this.config.continuousMode && !this.isDucked && this.state !== 'MUTED' && this.state !== 'DISABLED') {
          this.scheduleRestart(300);
        } else if (!this.config.continuousMode) {
          this.setState('IDLE');
        }
      };

      return true;
    } catch (err) {
      console.error('VoiceController initialization failed', err);
      this.setState('DISABLED');
      return false;
    }
  }

  private updateRecognitionLanguage(): void {
    if (!this.recognition) return;
    // Set speech recognition locale hint
    this.recognition.lang = this.config.defaultLanguage === 'hi' ? 'hi-IN' : 'en-IN';
  }

  private setState(newState: VoiceState): void {
    if (this.state !== newState) {
      this.state = newState;
      this.config.onStateChange?.(newState);
    }
  }

  /**
   * Process a captured speech transcript
   */
  public handleTranscript(transcript: string): MatchedCommand {
    this.setState('PROCESSING');
    this.config.onTranscript?.(transcript, true);

    const matched = matchVoiceCommand(transcript, this.config.defaultLanguage);

    if (matched.intent !== VoiceIntent.UNKNOWN) {
      this.audioCues.playCue(AudioCueType.COMMAND_ACK);
      this.executeBuiltInIntent(matched);
    } else {
      this.audioCues.playCue(AudioCueType.COMMAND_ERROR);
      const fallbackMsg = INTENT_RESPONSES[VoiceIntent.UNKNOWN][this.config.defaultLanguage];
      this.tts.speak(fallbackMsg, SpeechPriority.NORMAL, this.config.defaultLanguage);
    }

    this.config.onCommandMatched?.(matched);
    return matched;
  }

  /**
   * Internal handler for system-level voice intents
   */
  private executeBuiltInIntent(command: MatchedCommand): void {
    const lang = this.config.defaultLanguage;

    switch (command.intent) {
      case VoiceIntent.SET_LANGUAGE_HINDI:
        this.setLanguage('hi');
        break;

      case VoiceIntent.SET_LANGUAGE_ENGLISH:
        this.setLanguage('en');
        break;

      case VoiceIntent.MUTE:
        this.setMuted(true);
        break;

      case VoiceIntent.UNMUTE:
        this.setMuted(false);
        break;

      case VoiceIntent.REPEAT_LAST_ALERT:
        this.tts.speak(this.lastAlertText, SpeechPriority.NORMAL, lang);
        break;

      case VoiceIntent.INCREASE_SPEED:
        this.tts.setRate(this.tts.getRate() + 0.2);
        this.tts.speak(INTENT_RESPONSES[command.intent][lang], SpeechPriority.NORMAL, lang);
        break;

      case VoiceIntent.DECREASE_SPEED:
        this.tts.setRate(this.tts.getRate() - 0.2);
        this.tts.speak(INTENT_RESPONSES[command.intent][lang], SpeechPriority.NORMAL, lang);
        break;

      case VoiceIntent.BATTERY_STATUS:
        this.reportBatteryStatus();
        break;

      default:
        // Feedback response for navigation / scene queries
        const responseText = INTENT_RESPONSES[command.intent]?.[lang];
        if (responseText) {
          this.tts.speak(responseText, SpeechPriority.NORMAL, lang);
        }
        break;
    }
  }

  private async reportBatteryStatus(): Promise<void> {
    const lang = this.config.defaultLanguage;
    if (typeof navigator !== 'undefined' && 'getBattery' in navigator) {
      try {
        const battery: any = await (navigator as any).getBattery();
        const pct = Math.round(battery.level * 100);
        const charging = battery.charging;
        const msg =
          lang === 'hi'
            ? `बैटरी ${pct} प्रतिशत है${charging ? ', और चार्ज हो रही है' : ''}।`
            : `Battery is at ${pct} percent${charging ? ', charging' : ''}.`;
        this.tts.speak(msg, SpeechPriority.NORMAL, lang);
        return;
      } catch (_) {}
    }
    const fallback =
      lang === 'hi'
        ? 'बैटरी की जानकारी उपलब्ध नहीं है।'
        : 'Battery information is unavailable.';
    this.tts.speak(fallback, SpeechPriority.NORMAL, lang);
  }

  /**
   * Triggered by screen gesture (e.g. single/double tap anywhere on screen)
   */
  public triggerPushToTalk(): void {
    if (this.isRecognizing) {
      this.stopListening();
    } else {
      this.audioCues.playCue(AudioCueType.LISTEN_START);
      this.startListening();
    }
  }

  public startListening(): void {
    if (this.isRecognizing || !this.recognition) return;
    try {
      this.recognition.start();
    } catch (err) {
      console.warn('VoiceController start error:', err);
    }
  }

  public stopListening(): void {
    if (this.restartTimeout) {
      clearTimeout(this.restartTimeout);
      this.restartTimeout = null;
    }
    if (this.recognition && this.isRecognizing) {
      try {
        this.recognition.stop();
        this.audioCues.playCue(AudioCueType.LISTEN_STOP);
      } catch (_) {}
    }
    this.setState('IDLE');
  }

  private scheduleRestart(delayMs: number): void {
    if (this.restartTimeout) clearTimeout(this.restartTimeout);
    this.restartTimeout = setTimeout(() => {
      if (!this.isRecognizing && !this.isDucked) {
        this.startListening();
      }
    }, delayMs);
  }

  /**
   * Safety Critical Alert:
   * Instantly preempts voice recognition and audio speech to announce immediate hazards.
   */
  public handleCriticalHazard(alertMessage: string, lang?: SupportedLanguage): void {
    this.lastAlertText = alertMessage;
    // Play alarming earcon immediately
    this.audioCues.playCue(AudioCueType.CRITICAL_HAZARD);
    // Preempt all speech and speak danger warning
    this.tts.speak(alertMessage, SpeechPriority.CRITICAL, lang || this.config.defaultLanguage);
  }

  /**
   * Standard obstacle alert with cooldown
   */
  public handleStandardAlert(
    alertMessage: string,
    priority: SpeechPriority = SpeechPriority.HIGH,
    lang?: SupportedLanguage
  ): void {
    this.lastAlertText = alertMessage;
    this.tts.speak(alertMessage, priority, lang || this.config.defaultLanguage);
  }

  public setLanguage(lang: SupportedLanguage): void {
    this.config.defaultLanguage = lang;
    this.tts.setLanguage(lang);
    this.updateRecognitionLanguage();
    const ack = INTENT_RESPONSES[lang === 'hi' ? VoiceIntent.SET_LANGUAGE_HINDI : VoiceIntent.SET_LANGUAGE_ENGLISH][lang];
    this.tts.speak(ack, SpeechPriority.NORMAL, lang);
  }

  public setMuted(muted: boolean): void {
    this.audioCues.setMuted(muted);
    if (muted) {
      this.setState('MUTED');
      this.stopListening();
    } else {
      this.setState('IDLE');
      if (this.config.continuousMode) {
        this.startListening();
      }
    }
  }

  public getState(): VoiceState {
    return this.state;
  }

  public getAudioCues(): AudioCueManager {
    return this.audioCues;
  }

  public getTTS(): TTSEngine {
    return this.tts;
  }
}

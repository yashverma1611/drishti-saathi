/**
 * Drishti Saathi - Synthetic Earcons & Audio Cues
 * Web Audio API synthesizer for zero-latency, offline tactile & auditory cues.
 */

import { AudioCueType } from './types';

export class AudioCueManager {
  private ctx: AudioContext | null = null;
  private isMuted: boolean = false;

  constructor() {
    // Lazily initialized on first user interaction to comply with browser autoplay policies
  }

  private initContext(): AudioContext {
    if (!this.ctx || this.ctx.state === 'closed') {
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      this.ctx = new AudioCtxClass();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
    return this.ctx;
  }

  public setMuted(muted: boolean): void {
    this.isMuted = muted;
  }

  /**
   * Play standard assistive earcon
   */
  public playCue(type: AudioCueType): void {
    if (this.isMuted && type !== AudioCueType.CRITICAL_HAZARD) {
      return;
    }

    try {
      const ctx = this.initContext();
      const now = ctx.currentTime;

      switch (type) {
        case AudioCueType.LISTEN_START:
          // Rising two-tone chime (440Hz -> 660Hz) to signal mic listening
          this.playTone(440, now, 0.1, 0.15);
          this.playTone(660, now + 0.1, 0.15, 0.2);
          this.vibrate([40]);
          break;

        case AudioCueType.LISTEN_STOP:
          // Descending soft click
          this.playTone(520, now, 0.08, 0.15);
          this.playTone(390, now + 0.08, 0.1, 0.15);
          break;

        case AudioCueType.COMMAND_ACK:
          // Affirmative bright chime (587Hz -> 880Hz)
          this.playTone(587.33, now, 0.09, 0.2); // D5
          this.playTone(880.00, now + 0.09, 0.16, 0.25); // A5
          this.vibrate([60, 40, 60]);
          break;

        case AudioCueType.COMMAND_ERROR:
          // Low dissonance double buzz (240Hz / 220Hz)
          this.playTone(240, now, 0.12, 0.3, 'sawtooth');
          this.playTone(200, now + 0.14, 0.15, 0.3, 'sawtooth');
          this.vibrate([150]);
          break;

        case AudioCueType.CRITICAL_HAZARD:
          // High urgent alarm pulse (880Hz -> 1320Hz)
          this.playUrgentAlarm(now);
          this.vibrate([100, 50, 100, 50, 200]);
          break;

        case AudioCueType.NAV_STARTED:
          // Ascending major triad (C-E-G)
          this.playTone(523.25, now, 0.08, 0.15); // C5
          this.playTone(659.25, now + 0.08, 0.08, 0.15); // E5
          this.playTone(783.99, now + 0.16, 0.18, 0.2); // G5
          this.vibrate([100]);
          break;

        case AudioCueType.NAV_STOPPED:
          // Descending triad (G-E-C)
          this.playTone(783.99, now, 0.08, 0.15);
          this.playTone(659.25, now + 0.08, 0.08, 0.15);
          this.playTone(523.25, now + 0.16, 0.2, 0.2);
          this.vibrate([80, 40, 80]);
          break;

        case AudioCueType.PATH_CLEAR:
          // Soft melodious two-note indicator (clear path)
          this.playTone(659.25, now, 0.12, 0.12); // E5
          this.playTone(987.77, now + 0.12, 0.2, 0.15); // B5
          break;
      }
    } catch (e) {
      console.warn('AudioCueManager: Web Audio playback failed', e);
    }
  }

  private playTone(
    freq: number,
    startTime: number,
    duration: number,
    gainLevel: number,
    type: OscillatorType = 'sine'
  ): void {
    if (!this.ctx) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = type;
    osc.frequency.setValueAtTime(freq, startTime);

    gain.gain.setValueAtTime(0.001, startTime);
    gain.gain.exponentialRampToValueAtTime(gainLevel, startTime + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, startTime + duration);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(startTime);
    osc.stop(startTime + duration);
  }

  private playUrgentAlarm(startTime: number): void {
    if (!this.ctx) return;
    // Two rapid sharp beeps
    this.playTone(1046.5, startTime, 0.08, 0.4, 'triangle');
    this.playTone(1318.5, startTime + 0.09, 0.1, 0.45, 'triangle');
    this.playTone(1046.5, startTime + 0.22, 0.08, 0.4, 'triangle');
    this.playTone(1318.5, startTime + 0.31, 0.12, 0.45, 'triangle');
  }

  private vibrate(pattern: number[]): void {
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate(pattern);
      } catch (_) {}
    }
  }
}

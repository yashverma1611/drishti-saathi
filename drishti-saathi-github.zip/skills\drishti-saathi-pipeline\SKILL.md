---
name: drishti-saathi-pipeline
description: Pipeline harness for executing local object detection, monocular depth estimation, spatial risk assessment, and bilingual voice command parsing for the Drishti Saathi assistive system.
---

# Drishti Saathi Edge AI Pipeline Skill

This agent skill encapsulates the full edge AI processing pipeline for Drishti Saathi. It allows autonomous agents or automated testing harnesses to execute frame risk scoring, evaluate obstacle collision zones, and parse multi-lingual voice commands.

## Capabilities

1. **Spatial Risk Assessment**:
   - Computes normalized bounding-box horizontal alignment (`LEFT`, `CENTER`, `RIGHT`).
   - Evaluates depth zones (`VERY_CLOSE`, `NEAR`, `FAR`).
   - Categorizes priority levels (`CRITICAL`, `HIGH`, `LOW`).

2. **Bilingual Voice Intent Parsing**:
   - Parses English, Hindi (Devanagari), and Hinglish command queries.
   - Extracts navigation commands, scene queries, and speech adjustments.

3. **Privacy Compliance Verification**:
   - Ensures no frames or raw audio are transmitted over external networks or persisted to permanent disk storage.

## Usage Guide

To run unit evaluation on a sample frame detection:

```bash
node scripts/evaluate_risk.js --label="pole" --xMin=0.4 --yMin=0.3 --xMax=0.6 --yMax=0.8 --lang="hi"
```

Output:
```json
{
  "objectLabel": "pole",
  "riskScore": 90,
  "priority": 4,
  "direction": "CENTER",
  "depthZone": "VERY_CLOSE",
  "alertText": {
    "en": "Stop! pole directly ahead.",
    "hi": "रुकिए! सामने खंभा है।"
  }
}
```

$port = 8080
$scriptDir = $PSScriptRoot
if (-not $scriptDir -and $MyInvocation.MyCommand.Path) { $scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path }
if (-not $scriptDir) { $scriptDir = "C:\Users\KRIN\.gemini\antigravity\scratch\drishti-saathi" }
$folder = Join-Path $scriptDir "app"

Write-Host ""
Write-Host "========================================================" -ForegroundColor Cyan
Write-Host "  Drishti Saathi Local Server Live at http://localhost:$port/" -ForegroundColor Green
Write-Host "  Serving from: $folder" -ForegroundColor Yellow
Write-Host "  Full Camera, Microphone & Voice Enabled!" -ForegroundColor Green
Write-Host "========================================================" -ForegroundColor Cyan
Write-Host ""

$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://localhost:$port/")
$listener.Prefixes.Add("http://127.0.0.1:$port/")
try {
    $listener.Prefixes.Add("http://192.168.31.68:$port/")
} catch {}
try {
    $listener.Start()
} catch {
    # If 192.168... failed due to permissions, fallback to localhost only
    $listener = New-Object System.Net.HttpListener
    $listener.Prefixes.Add("http://localhost:$port/")
    $listener.Prefixes.Add("http://127.0.0.1:$port/")
    $listener.Start()
}

# Launch in default browser
Start-Process "http://localhost:$port/"

while ($listener.IsListening) {
    try {
        $ctx = $listener.GetContext()
        $req = $ctx.Request
        $resp = $ctx.Response

        $rel = $req.Url.AbsolutePath.TrimStart('/')
        if ([string]::IsNullOrEmpty($rel)) { $rel = 'index.html' }
        $filePath = Join-Path $folder $rel

        if (Test-Path $filePath -PathType Leaf) {
            $bytes = [System.IO.File]::ReadAllBytes($filePath)
            $ext = [System.IO.Path]::GetExtension($filePath).ToLower()
            $mime = 'text/plain'
            switch ($ext) {
                '.html' { $mime = 'text/html; charset=utf-8' }
                '.js'   { $mime = 'application/javascript; charset=utf-8' }
                '.css'  { $mime = 'text/css; charset=utf-8' }
                '.json' { $mime = 'application/json; charset=utf-8' }
                '.png'  { $mime = 'image/png' }
                '.jpg'  { $mime = 'image/jpeg' }
                '.svg'  { $mime = 'image/svg+xml' }
            }
            $resp.ContentType = $mime
            $resp.ContentLength64 = $bytes.Length
            $resp.OutputStream.Write($bytes, 0, $bytes.Length)
        } else {
            $resp.StatusCode = 404
        }
        $resp.Close()
    } catch {
        # Continue listening
    }
}

/**
 * Drishti Saathi - Speech Synthesis Engine (TTS)
 * Manages priority-based queuing, critical alert preemption, speech rate, and microphone ducking.
 */

import { SupportedLanguage, SpeechPriority, SpeechRequest } from './types';

export class TTSEngine {
  private synth: SpeechSynthesis | null = null;
  private queue: SpeechRequest[] = [];
  private currentRequest: SpeechRequest | null = null;
  private isSpeaking: boolean = false;
  private speechRate: number = 1.05; // Slightly brisk for responsive navigation
  private pitch: number = 1.0;
  private currentLanguage: SupportedLanguage = 'en';

  // Cooldown cache: phrase -> timestamp
  private cooldownMap: Map<string, number> = new Map();
  private readonly DEFAULT_COOLDOWN_MS = 3000;

  // Listeners for mic ducking
  public onSpeechStart?: () => void;
  public onSpeechEnd?: () => void;

  constructor() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      this.synth = window.speechSynthesis;
    }
  }

  public setLanguage(lang: SupportedLanguage): void {
    this.currentLanguage = lang;
  }

  public getLanguage(): SupportedLanguage {
    return this.currentLanguage;
  }

  public setRate(rate: number): void {
    this.speechRate = Math.max(0.7, Math.min(2.0, rate));
  }

  public getRate(): number {
    return this.speechRate;
  }

  /**
   * Speak an alert with priority management
   */
  public speak(
    text: string,
    priority: SpeechPriority = SpeechPriority.NORMAL,
    language?: SupportedLanguage,
    cooldownMs: number = this.DEFAULT_COOLDOWN_MS
  ): boolean {
    if (!this.synth) {
      console.warn('TTSEngine: speechSynthesis not supported on this platform');
      return false;
    }

    const lang = language || this.currentLanguage;
    const now = Date.now();

    // Check cooldown for repetitive non-critical warnings
    if (priority < SpeechPriority.CRITICAL) {
      const lastSpoken = this.cooldownMap.get(text) || 0;
      if (now - lastSpoken < cooldownMs) {
        return false; // Suppressed by cooldown
      }
    }
    this.cooldownMap.set(text, now);

    const request: SpeechRequest = {
      id: `${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      text,
      language: lang,
      priority,
    };

    // If CRITICAL: Preempt immediately
    if (priority === SpeechPriority.CRITICAL) {
      this.preemptAndSpeak(request);
      return true;
    }

    // Otherwise insert into priority queue
    this.enqueue(request);
    this.processQueue();
    return true;
  }

  /**
   * Stop all active and queued speech
   */
  public stop(): void {
    this.queue = [];
    if (this.synth) {
      this.synth.cancel();
    }
    this.isSpeaking = false;
    this.currentRequest = null;
    this.onSpeechEnd?.();
  }

  private enqueue(req: SpeechRequest): void {
    // Insert sorted by priority descending
    const idx = this.queue.findIndex((item) => item.priority < req.priority);
    if (idx === -1) {
      this.queue.push(req);
    } else {
      this.queue.splice(idx, 0, req);
    }

    // Limit queue size to avoid backlog lag
    if (this.queue.length > 5) {
      this.queue = this.queue.filter((item) => item.priority >= SpeechPriority.HIGH).slice(0, 4);
    }
  }

  private preemptAndSpeak(req: SpeechRequest): void {
    if (this.synth) {
      this.synth.cancel();
    }
    // Drop lower priority queued items
    this.queue = this.queue.filter((item) => item.priority >= SpeechPriority.HIGH);
    this.executeUtterance(req);
  }

  private processQueue(): void {
    if (this.isSpeaking || this.queue.length === 0) return;
    const next = this.queue.shift();
    if (next) {
      this.executeUtterance(next);
    }
  }

  private executeUtterance(req: SpeechRequest): void {
    if (!this.synth) return;

    this.isSpeaking = true;
    this.currentRequest = req;
    this.onSpeechStart?.();

    const utterance = new SpeechSynthesisUtterance(req.text);
    utterance.rate = req.rate || this.speechRate;
    utterance.pitch = req.pitch || this.pitch;

    // Resolve best voice
    const voiceLang = req.language === 'hi' ? 'hi-IN' : 'en-IN';
    utterance.lang = voiceLang;

    const voices = this.synth.getVoices();
    const matchedVoice = voices.find((v) =>
      req.language === 'hi'
        ? v.lang.startsWith('hi') || v.name.toLowerCase().includes('hindi')
        : v.lang === 'en-IN' || v.lang.startsWith('en')
    );
    if (matchedVoice) {
      utterance.voice = matchedVoice;
    }

    utterance.onstart = () => {
      req.onStart?.();
    };

    utterance.onend = () => {
      this.isSpeaking = false;
      this.currentRequest = null;
      req.onEnd?.();
      this.onSpeechEnd?.();
      // Continue queue
      this.processQueue();
    };

    utterance.onerror = (err) => {
      console.warn('TTSEngine: utterance error', err);
      this.isSpeaking = false;
      this.currentRequest = null;
      req.onError?.(err);
      this.onSpeechEnd?.();
      this.processQueue();
    };

    this.synth.speak(utterance);
  }

  public getIsSpeaking(): boolean {
    return this.isSpeaking;
  }
}

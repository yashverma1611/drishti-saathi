# Drishti Saathi — Open-Source AI Models Specification

In compliance with hackathon regulations, all AI models integrated or targeted for Drishti Saathi are open-weight and use permissive licenses (**Apache 2.0** or **MIT**). Permissively licensed models prevent IP conflict and enable unencumbered offline edge deployment.

---

## 1. Model Catalog & Provenance

| Pipeline Stage | Model Identifier | Architecture | License | Format / Runtime | Primary Source / Hub |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Real-time Object Detection** | **YOLOX-Nano / Small** | Anchor-free CNN | **Apache 2.0** | ONNX (INT8/FP16) via ONNX Runtime Web | [MegEngine/YOLOX](https://github.com/Megvii-BaseDetection/YOLOX) |
| **Alternative Detection** | **RT-DETR-R18** | Vision Transformer | **Apache 2.0** | ONNX via ONNX Runtime Web | [Baidu/RT-DETR](https://github.com/lyuwenyu/RT-DETR) |
| **Monocular Depth Estimation** | **Depth Anything V2 Small** | DPT / Vision Transformer | **Apache 2.0** | ONNX via ONNX Runtime Web | [Depth-Anything-V2-Small](https://huggingface.co/depth-anything/Depth-Anything-V2-Small) |
| **Depth Fallback** | **MiDaS v2.1 Small** | EfficientNet-Backbone DPT | **MIT** | ONNX via ONNX Runtime Web | [intel-isl/MiDaS](https://github.com/isl-org/MiDaS) |
| **On-Demand Scene Description** | **SmolVLM-500M / Moondream2** | Compact Vision-Language | **Apache 2.0** | WebGPU / Transformers.js | [HuggingFaceTB/SmolVLM-500M](https://huggingface.co/HuggingFaceTB/SmolVLM-500M-Instruct) |
| **Local Speech Recognition** | **Web Speech API / Sherpa-ONNX Whisper-Tiny** | Transducer / Transformer | **Apache 2.0** | Native Edge Engine / ONNX | [k2-fsa/sherpa-onnx](https://github.com/k2-fsa/sherpa-onnx) |
| **Speech Synthesis (TTS)** | **W3C Web Speech Synthesis** | Device Native Offline Engine | **Open Web Standard** | Device Native (zero cloud calls) | OS Local Voice Pack (Hindi & English) |

> [!NOTE]
> **Licensing Warning on Ultralytics YOLO**: Ultralytics YOLOv8/v11 is licensed under AGPL-3.0, which imposes copyleft network requirements. Drishti Saathi strictly uses **YOLOX (Apache 2.0)** or **RT-DETR (Apache 2.0)** to maintain MIT/Apache compatibility.

---

## 2. Model Download Automation Script

Model weights are downloaded directly to the client or local runner and never checked into Git repository history.

Run the platform-specific download helper:

### Windows PowerShell:
```powershell
./models/download_models.ps1
```

### Linux / macOS:
```bash
chmod +x ./models/download_models.sh
./models/download_models.sh
```

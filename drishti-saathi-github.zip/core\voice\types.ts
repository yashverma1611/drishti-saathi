/**
 * Drishti Saathi - Voice Control System Types
 * Offline, Privacy-First Assistive Tech
 */

export type SupportedLanguage = 'en' | 'hi';

export enum VoiceIntent {
  // Scene understanding
  DESCRIBE_SCENE = 'DESCRIBE_SCENE',
  
  // Navigation State
  START_NAVIGATION = 'START_NAVIGATION',
  PAUSE_NAVIGATION = 'PAUSE_NAVIGATION',
  RESUME_NAVIGATION = 'RESUME_NAVIGATION',
  STOP_NAVIGATION = 'STOP_NAVIGATION',
  
  // Environment & Path queries
  CHECK_PATH_STATUS = 'CHECK_PATH_STATUS',
  REPEAT_LAST_ALERT = 'REPEAT_LAST_ALERT',
  
  // Language & Voice Settings
  SET_LANGUAGE_HINDI = 'SET_LANGUAGE_HINDI',
  SET_LANGUAGE_ENGLISH = 'SET_LANGUAGE_ENGLISH',
  INCREASE_SPEED = 'INCREASE_SPEED',
  DECREASE_SPEED = 'DECREASE_SPEED',
  MUTE = 'MUTE',
  UNMUTE = 'UNMUTE',
  
  // Assistance
  HELP = 'HELP',
  BATTERY_STATUS = 'BATTERY_STATUS',
  
  // Unrecognized
  UNKNOWN = 'UNKNOWN',
}

export interface MatchedCommand {
  intent: VoiceIntent;
  rawText: string;
  confidence: number;
  detectedLanguage: SupportedLanguage;
  matchedPattern?: string;
}

export enum AudioCueType {
  LISTEN_START = 'LISTEN_START',
  LISTEN_STOP = 'LISTEN_STOP',
  COMMAND_ACK = 'COMMAND_ACK',
  COMMAND_ERROR = 'COMMAND_ERROR',
  CRITICAL_HAZARD = 'CRITICAL_HAZARD',
  NAV_STARTED = 'NAV_STARTED',
  NAV_STOPPED = 'NAV_STOPPED',
  PATH_CLEAR = 'PATH_CLEAR',
}

export enum SpeechPriority {
  LOW = 1,        // Periodic status, scene description details
  NORMAL = 2,     // Standard feedback, command responses
  HIGH = 3,       // Nearby non-critical obstacles
  CRITICAL = 4,   // Immediate collisions, stairs, steep drop-offs (preempts all speech)
}

export interface SpeechRequest {
  id: string;
  text: string;
  language: SupportedLanguage;
  priority: SpeechPriority;
  rate?: number;
  pitch?: number;
  onStart?: () => void;
  onEnd?: () => void;
  onError?: (err: any) => void;
}

export type VoiceState = 'IDLE' | 'LISTENING' | 'PROCESSING' | 'SPEAKING' | 'MUTED' | 'DISABLED';

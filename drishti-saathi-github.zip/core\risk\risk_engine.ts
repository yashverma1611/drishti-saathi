/**
 * Drishti Saathi - Spatial Risk Engine
 * Computes collision probability and risk score from bounding box & depth zone.
 */

import { SpeechPriority, SupportedLanguage } from '../voice/types';

export type SpatialZone = 'LEFT' | 'CENTER' | 'RIGHT';
export type DepthZone = 'VERY_CLOSE' | 'NEAR' | 'FAR';

export interface DetectedObject {
  label: string;
  confidence: number;
  // Normalized coordinates [0, 1]
  bbox: {
    xMin: number;
    yMin: number;
    xMax: number;
    yMax: number;
  };
  estimatedDepthMeters?: number;
  depthZone?: DepthZone;
}

export interface RiskAssessment {
  objectLabel: string;
  riskScore: number; // 0 to 100
  priority: SpeechPriority;
  direction: SpatialZone;
  depthZone: DepthZone;
  alertText: {
    en: string;
    hi: string;
  };
}

// Objects posing severe tripping or impact hazards
const CRITICAL_OBJECTS = new Set([
  'stairs',
  'step',
  'pothole',
  'hole',
  'drop',
  'car',
  'truck',
  'bus',
  'motorcycle',
  'pole',
]);

export class SpatialRiskEngine {
  /**
   * Determine horizontal zone from bbox center
   */
  public getDirection(bbox: DetectedObject['bbox']): SpatialZone {
    const centerX = (bbox.xMin + bbox.xMax) / 2;
    if (centerX < 0.35) return 'LEFT';
    if (centerX > 0.65) return 'RIGHT';
    return 'CENTER';
  }

  /**
   * Determine depth zone based on bbox height & depth sensor/model
   */
  public getDepthZone(obj: DetectedObject): DepthZone {
    if (obj.depthZone) return obj.depthZone;

    // Fallback heuristic: large bounding box in camera view means object is very close
    const bboxHeight = obj.bbox.yMax - obj.bbox.yMin;
    if (bboxHeight > 0.65 || (obj.estimatedDepthMeters && obj.estimatedDepthMeters < 1.2)) {
      return 'VERY_CLOSE';
    }
    if (bboxHeight > 0.35 || (obj.estimatedDepthMeters && obj.estimatedDepthMeters < 2.5)) {
      return 'NEAR';
    }
    return 'FAR';
  }

  /**
   * Calculate comprehensive risk score and alert priority
   */
  public evaluateRisk(obj: DetectedObject): RiskAssessment {
    const direction = this.getDirection(obj.bbox);
    const depthZone = this.getDepthZone(obj);
    const isCriticalObj = CRITICAL_OBJECTS.has(obj.label.toLowerCase());

    let baseScore = 30;

    // Depth penalty
    if (depthZone === 'VERY_CLOSE') baseScore += 50;
    else if (depthZone === 'NEAR') baseScore += 30;
    else baseScore += 10;

    // Direction penalty (objects directly in the walking center path are hazardous)
    if (direction === 'CENTER') baseScore += 20;
    else baseScore += 5;

    // Object type multiplier
    if (isCriticalObj) baseScore += 20;

    const riskScore = Math.min(100, baseScore);

    // Assign speech priority
    let priority: SpeechPriority;
    if (riskScore >= 85 || (depthZone === 'VERY_CLOSE' && direction === 'CENTER')) {
      priority = SpeechPriority.CRITICAL;
    } else if (riskScore >= 60) {
      priority = SpeechPriority.HIGH;
    } else {
      priority = SpeechPriority.LOW;
    }

    const alertText = this.generateAlertText(obj.label, direction, depthZone, priority);

    return {
      objectLabel: obj.label,
      riskScore,
      priority,
      direction,
      depthZone,
      alertText,
    };
  }

  private generateAlertText(
    label: string,
    dir: SpatialZone,
    depth: DepthZone,
    priority: SpeechPriority
  ): { en: string; hi: string } {
    const dirMapEn: Record<SpatialZone, string> = {
      LEFT: 'on your left',
      CENTER: 'ahead',
      RIGHT: 'on your right',
    };
    const dirMapHi: Record<SpatialZone, string> = {
      LEFT: 'बाईं तरफ',
      CENTER: 'सामने',
      RIGHT: 'दाईं तरफ',
    };

    const labelLower = label.toLowerCase();

    // Critical step / stairs alerts
    if (labelLower.includes('stair') || labelLower.includes('step') || labelLower.includes('drop')) {
      return {
        en: `Warning: Stairs ${dirMapEn[dir]}, walk carefully.`,
        hi: `सावधान: ${dirMapHi[dir]} सीढ़ियाँ हैं, संभलकर चलें।`,
      };
    }

    if (depth === 'VERY_CLOSE') {
      return {
        en: `Stop! ${label} directly ${dirMapEn[dir]}.`,
        hi: `रुकिए! ${dirMapHi[dir]} ${this.translateLabelHi(label)} है।`,
      };
    }

    return {
      en: `${label} ${dirMapEn[dir]}.`,
      hi: `${dirMapHi[dir]} ${this.translateLabelHi(label)} है।`,
    };
  }

  private translateLabelHi(label: string): string {
    const dict: Record<string, string> = {
      person: 'व्यक्ति',
      car: 'गाड़ी',
      pole: 'खंभा',
      chair: 'कुर्सी',
      bicycle: 'साइकिल',
      motorcycle: 'बाइक',
      door: 'दरवाजा',
      stairs: 'सीढ़ियाँ',
      pothole: 'गड्ढा',
    };
    return dict[label.toLowerCase()] || label;
  }
}
